// Firebase Console > Project settings > Your apps bölümünden değerleri gir.
// Bu dosyaya yönetici/private service-account anahtarı ASLA koyma.
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "BURAYA_FIREBASE_API_KEY",
  authDomain: "BURAYA_PROJECT_ID.firebaseapp.com",
  projectId: "BURAYA_PROJECT_ID",
  appId: "BURAYA_FIREBASE_APP_ID"
};

export const firebaseConfigured = !Object.values(firebaseConfig).some(v => String(v).includes("BURAYA_"));
export const auth = firebaseConfigured ? getAuth(initializeApp(firebaseConfig)) : null;
