# ModaSepet — GitHub'a yükleme ve kurulum (Türkçe)

Bu proje 30 ürünlü bir moda mağazası demosudur. Ürün arama, kategori filtreleme, sıralama ve sepet içerir. Firebase bağlandığında e-posta/şifre kaydı, e-posta doğrulaması ve SMS ile telefon doğrulama akışı kullanılabilir.

## GitHub'a yükle
1. GitHub hesabına gir: https://github.com/new
2. Repository name: `modasepet` yaz.
3. Public veya Private seç ve **Create repository** de.
4. ZIP dosyasını bilgisayarına indirip çıkar.
5. Depoda **Add file → Upload files** seç; klasör içindeki `index.html`, `package.json`, `src` klasörü ve `README_TR.md` dosyasını yükle ve commit et.

## Firebase'i bağla
1. https://console.firebase.google.com/ aç ve proje oluştur.
2. Project settings → Your apps → Web App ekle.
3. Firebase web config içindeki `apiKey`, `authDomain`, `projectId`, `appId` değerlerini `src/firebase.js` dosyasındaki örneklerle değiştir.
4. Authentication → Sign-in method içinde **Email/Password** ve **Phone** sağlayıcılarını aç.
5. Authentication ayarlarında SMS bölge politikalarını, kota ve gerekiyorsa faturalandırmayı kontrol et.
6. Authentication → Settings → Authorized domains alanına yayınlama alan adını ekle. Geliştirme için `localhost` ekle.
7. Firebase web config içindeki API key web istemcisi yapılandırmasıdır; asla service-account private key koyma.

## Yerelde çalıştır
Node.js kurduktan sonra proje klasöründe terminal aç:
```bash
npm install
npm run dev
```
Terminalin verdiği yerel adresi aç. Firebase Console'da `localhost` izinli olmalı.

## GitHub Pages ile yayınlama
Bu Vite projesi GitHub Pages için build gerektirir. En kolay yöntem Vercel/Netlify gibi Vite destekleyen statik host kullanmaktır:
- GitHub reposunu Vercel veya Netlify'a bağla.
- Build command: `npm run build`
- Output directory: `dist`
- Yayınlanan domaini Firebase Authentication → Authorized domains'e ekle.

GitHub Pages kullanmak istersen Vite `base` ayarını repository adına göre düzenlemek ve deploy workflow eklemek gerekir; Vercel/Netlify başlangıç için daha basittir.

## Güvenlik notları
- Şifreler ve SMS doğrulama kodları site yöneticisine gösterilmez ve gösterilmemelidir.
- E-posta doğrulama ve SMS doğrulama gerçek mesaj gönderimi için Firebase ayarları ister; SMS ücretli veya limitli olabilir.
- Bu örnekte gerçek sipariş veritabanı, admin paneli veya ödeme sağlayıcısı yoktur. Sepet tarayıcı belleğindedir.
- Üretim için müşteri mesajları/siparişler yönetici paneline eklenebilir; kullanıcı şifrelerini veya SMS kodlarını kaydetme.
- Gerçek siparişler için backend/veritabanı, güvenlik kuralları, gizlilik politikası ve GDPR kontrolleri gerekir.
